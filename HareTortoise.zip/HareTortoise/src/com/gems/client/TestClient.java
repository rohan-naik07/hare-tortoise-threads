/**
 * 
 */
package com.gems.client;

import com.gems.race.Hare;
import com.gems.race.Race;
import com.gems.race.Tortoise;
import com.gems.thread.RunnableClass;
import com.gems.thread.SmartException;

/**
 * @author Administrator
 *
 */
public class TestClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		System.out.println(Thread.currentThread().getName() + "-");
//		RunnableClass r1 = new RunnableClass();
//		Thread t1 = new Thread(r1);
//		t1.start();
//		RunnableClass r2 = new RunnableClass();
//		Thread t2 = new Thread(r2);
//		t2.start();
//		RunnableClass r3 = new RunnableClass();
//		Thread t3 = new Thread(r3);
//		t3.start();
//		System.out.println(Thread.currentThread().getName() + "-");
//		Thread t4 = new Thread() {
//			@Override
//			public void run() {
//				System.out.println(Thread.currentThread().getName() + "-");
//				try {
//					Thread.sleep(1000);
//				} catch (InterruptedException e) {
//					// TODO Auto-generated catch block
//					System.out.println("Thread interrupted");
//				}
//				System.out.println("Thread finished");
//			}
//		};
//		System.out.println("Main thread started");
//		t4.start();
//		try {
//			Thread.sleep(1000);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//		System.out.println("Main Thread interrupted t1");
//		t4.interrupt();
//		//test(); error.. surround with try catch
////		try {
////			test();
////		} catch(Exception s) {
////			
////		}
//		System.out.println("Main Thread finished");
		Race r1 = new Race();
		r1.start();
	}
	
	public static void test() throws SmartException {
		throw new SmartException();
	}

}
